### v0.0.6 - 2.20.2022
* init commit

### v0.0.7 - 2.20.2022
* update update.json 

### v0.0.8 - 2.28.2022
* replace dd rm instead of replacing toybox since it may cause bootloop

### v0.0.9 - 3.04.2022
* block shred
* add install.zip so that there is no need to release 
