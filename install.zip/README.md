This is a magisk module can automatically deny dd/rm command by overlaying a toybox script on the toybox bin
>Please use `toybox DD` or `toybox RM` instead

# It may not work properly or make other module which use `dd` `rm` command since it is an experimental project
